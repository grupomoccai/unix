#include <stdio.h>
#include <stdlib.h>
int main() {
  char *home_ = getenv("HOME");
  printf("hola mundo! home=%s\n", home_);
  return 0;
}
